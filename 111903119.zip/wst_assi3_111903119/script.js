function validate(){  
	var result = "";	
	result += validateFirstName(); 	
	result += validateLastName();
	result += validateEmail();
	result += validateCountry();
	result += validateState();
	if (result == "") return true;
	
	alert("Validation Result:\n\n" + result);
	return false;	
}

function validateFirstName(){
	var name = document.getElementsByName("Firstname")[0].value;
	if (name.length <= 2)
		return "First name should be at least two characters.\n";	
	return "";
}

function validateLastName(){
	var name = document.getElementsByName("Lastname")[0].value;
	if (name.length <= 2)
		return "Last name should be at least two characters.\n";	
	return "";
}

function validateCountry(){
	var name = document.getElementsByName("country")[0].value;
	if (name.length <= 2)
		return "Country name should be at least two characters.\n";	
	return "";
}


function validateState(){
	var name = document.getElementsByName("state")[0].value;
	if (name.length <= 2)
		return "State name should be at least two characters.\n";	
	return "";
}


function validateEmail(){
	var email = valueOf("email");
	var retype = valueOf("retype_email");
	
	if (email.indexOf('@') == -1) 
		return "Email should be a valid address.\n";
	
	if (email != retype)
		return "Email addresses do not match.\n";
	return "";	
}

function valueOf(name){
	return document.getElementsByName(name)[0].value;
}